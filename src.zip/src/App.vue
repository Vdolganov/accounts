<!-- App.vue или AccountsView.vue -->
<script setup lang="ts">
import AccountFormRow from '@//components/AccountFormRow.vue';
import ButtonBlue from '@/components/ButtonBlue.vue';
import { useAccountsStore } from '@/stores/accounts';
import { PlusIcon } from '@radix-icons/vue';
import { accountsFormSchema } from '@/utils/validation';
import { useFieldArray, useForm } from 'vee-validate';
import type { TAccount } from '@/types/accounts';
import { watch } from 'vue';
import { ACCOUNT_TYPES } from './constants/accounts';

const accountsStore = useAccountsStore();


const { values, errors, validate } = useForm({
  initialValues: {
    accounts: [...accountsStore.accounts]
  },

  validationSchema: (formValues) => {
    const result = accountsFormSchema.safeParse(formValues)

    if (result.success) {
      return { values: result.data, errors: {} }
    }

    const formErrors: Record<string, string> = {}

    result.error.issues.forEach(issue => {
      const path = issue.path.join('.')
      formErrors[path] = issue.message
    })

    return {
      values: {},
      errors: formErrors
    }
  },
})

const { fields, push, remove } = useFieldArray("accounts")

function addAccount() {
  push({
    id: crypto.randomUUID(),
    type: ACCOUNT_TYPES.Ldap,
    marks: '',
    login: '',
    password: null
  })
}

watch(
  () => values.accounts,
  (val: TAccount[]) => {
    accountsStore.accounts = val
  },
  { deep: true }
)
</script>

<template>
  <div class="min-h-full">
    <pre> {{ accountsStore.accounts }} </pre>
    <header class="relative bg-white shadow-sm">
      <div class="mx-auto max-w-7xl px-4 py-6 sm:px-6 lg:px-8 flex flex-row w-full gap-2 items-center">
        <h1 class="text-3xl font-bold tracking-tight text-blue-600">Учетные записи</h1>
        <ButtonBlue @click="addAccount">
          <PlusIcon/>
        </ButtonBlue>
      </div>
    </header>

    <main>
      <div class="mx-auto max-w-7xl px-4 py-6 sm:px-6 lg:px-8">
        <div class="flex flex-col w-full gap-[20px]">
          <AccountFormRow
            v-for="(field, index) in fields"
            :key="field.key"
            :index="index"
            :account="(values.accounts[index] as TAccount)"
            @delete="remove(index)"
          />
        </div>
      </div>
    </main>
  </div>
</template>

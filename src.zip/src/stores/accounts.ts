import { ref } from 'vue'
import { defineStore } from 'pinia'
import type { TAccount } from '@/types/accounts'
import { ACCOUNT_TYPES } from '@/constants/accounts';

const defaultAccount: TAccount = {
  type: ACCOUNT_TYPES.Ldap,
  marks: '',
  login: '',
  password: '',
  id: '',
}

function accountToApiFormat(account: TAccount) {
  const marksArray = (account.marks || '').split(';').map(acc => ({ text: acc.trim() }));
  return {
    marks: marksArray,
    type: account.type,
    login: account.login,
    password: account.password || null,
  }
}

export const useAccountsStore = defineStore('accounts', () => {
  const accounts = ref<TAccount[]>([]);

  function updateAccountData(updatedAccount: TAccount) {
    const { id } = updatedAccount;

    accounts.value = accounts.value?.map(account => {
      return account.id === id ? updatedAccount : account
    })
  }

  function deleteAccount(accountId: string) {
    accounts.value = accounts.value?.filter(el => el.id !== accountId);
  }

  function addAccount() {
    accounts.value.push({...defaultAccount, id: crypto.randomUUID()})
  }

  function saveData() {
    console.log(accounts.value.map(el => accountToApiFormat(el)));
  }



  return { accounts, updateAccountData, deleteAccount, addAccount, saveData }
})

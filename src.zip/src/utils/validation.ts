import { z } from 'zod'
import { ACCOUNT_TYPES } from '@/constants/accounts'

export const accountSchema = z.discriminatedUnion('type', [
  z.object({
    id: z.string(),
    marks: z.string().min(1, 'Метка обязательна'),
    login: z.string().min(1, 'Логин обязателен'),
    type: z.literal(ACCOUNT_TYPES.Local),
    password: z.string().min(1, 'Пароль обязателен')
  }),
  z.object({
    id: z.string(),
    marks: z.string().min(1, 'Метка обязательна'),
    login: z.string().min(1, 'Логин обязателен'),
    type: z.literal(ACCOUNT_TYPES.Ldap),
    password: z.null()
  })
])

export const accountsFormSchema = z.object({
  accounts: z.array(accountSchema)
})

export type AccountsFormValues = z.infer<typeof accountsFormSchema>

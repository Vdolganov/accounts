<script lang="ts" setup>
import type { TAccount } from '@/types/accounts';
import SelectFieldWrapped from '@/components/fields/wrappedFields/SelectFieldWrapped.vue';
import TextFieldWrapped from '@/components/fields/wrappedFields/TextFieldWrapped.vue';
import { ACCOUNT_TYPES } from '@/constants/accounts';
import ButtonBlue from './ButtonBlue.vue';
import { TrashIcon } from '@radix-icons/vue';
import { computed } from 'vue';

interface IProps {
  index: number;
  account: TAccount;
}

interface IEmits {
  (e: 'delete'): void;
}

const props = defineProps<IProps>()
const emit = defineEmits<IEmits>();

const options = [
  {
    value: ACCOUNT_TYPES.Ldap,
    label: 'LDAP',
  },
  {
    value: ACCOUNT_TYPES.Local,
    label: 'Локальная',
  },
]

const gridClass = computed(() => props.account.type === ACCOUNT_TYPES.Local ? 'grid-cols-[1fr_1fr_1fr_1fr_auto]' : 'grid-cols-[1fr_1fr_1fr_auto]')

</script>

<template>
  <div class="grid gap-[10px] w-full items-center w-full p-4 border border-gray-200 rounded-lg" :class="gridClass">
    <TextFieldWrapped :field-name="`accounts[${index}].marks`" placeholder="Метка" label="Метка"
      class="w-full" />

    <SelectFieldWrapped :field-name="`accounts[${index}].type`" :options="options" placeholder="Тип"
      label="Тип" class="w-full" />

    <TextFieldWrapped :field-name="`accounts[${index}].login`" placeholder="Логин" label="Логин"
      class="w-full" />

    <TextFieldWrapped v-if="account.type === ACCOUNT_TYPES.Local || account.password !== null"
      type="password" :field-name="`accounts[${index}].password`" placeholder="Пароль" label="Пароль" class="w-full" />

    <!-- Кнопка удаления -->
    <div class="flex items-end lg:items-start justify-end lg:justify-start">
      <ButtonBlue @click="emit('delete')">
        <TrashIcon class="w-4 h-4" />
      </ButtonBlue>
    </div>
  </div>
</template>

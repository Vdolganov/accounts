<!-- components/FieldWrapper.vue -->
<script setup lang="ts">
interface Props {
  label?: string;
  error: string;
  required?: boolean;
}

const props =  defineProps<Props>();

const id = props.label ? crypto.randomUUID() : '';
</script>

<template>
  <div class="w-full">
    <label v-if="label" :for="id" class="block text-sm font-medium text-gray-700 mb-1">
      {{ label }}
      <span v-if="required" class="text-red-500 ml-1">*</span>
    </label>

    <slot :error="!!error" />
    <p v-if="error" class="mt-1 text-sm text-red-600">
      {{ error }}
    </p>
  </div>
</template>

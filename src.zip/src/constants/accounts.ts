export const ACCOUNT_TYPES = {
  Ldap: 'ldap',
  Local: 'local',
}
